package id.alfaku.auto

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val pickImage = 1001
    private lateinit var questionText: TextView
    private lateinit var resultText: TextView
    private lateinit var bankInput: EditText
    private lateinit var answerInput: EditText
    private val bank = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "ALFA KUIS AUTO"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F6F8.toInt())
        }
        val heading = TextView(this).apply {
            text = "ALFA KUIS AUTO\\nAsisten baca soal & bank jawaban"
            textSize = 23f; setTextColor(0xFF173B67.toInt())
        }
        root.addView(heading)
        val note = TextView(this).apply {
            text = "Gunakan untuk belajar dan memeriksa kecocokan jawaban. Aplikasi tidak menekan pilihan atau mengirim kuis."
            textSize = 13f; setPadding(0, 12, 0, 16)
        }
        root.addView(note)
        val scan = Button(this).apply { text = "PILIH SCREENSHOT SOAL (OCR)" }
        root.addView(scan)
        questionText = TextView(this).apply {
            text = "Teks soal akan muncul di sini."
            textSize = 16f; setPadding(12, 16, 12, 16)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(questionText)
        root.addView(TextView(this).apply {
            text = "BANK JAWABAN (satu baris: kata kunci|jawaban)"
            textSize = 14f; setPadding(0, 18, 0, 6)
        })
        bankInput = EditText(this).apply {
            hint = "contoh: konsentrasi|Kemampuan memusatkan perhatian"
            minLines = 3; gravity = Gravity.TOP
        }
        root.addView(bankInput)
        val save = Button(this).apply { text = "SIMPAN BANK JAWABAN" }
        root.addView(save)
        val match = Button(this).apply { text = "COCOKKAN SOAL" }
        root.addView(match)
        resultText = TextView(this).apply {
            text = "Hasil pencocokan akan tampil di sini."
            textSize = 16f; setPadding(12, 16, 12, 16)
            setBackgroundColor(0xFFE7F0F8.toInt())
        }
        root.addView(resultText)
        answerInput = EditText(this).apply { hint = "Catatan jawaban / jawaban pilihan Anda" }
        root.addView(answerInput)
        val saveNote = Button(this).apply { text = "SIMPAN CATATAN" }
        root.addView(saveNote)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        scan.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(intent, "Pilih screenshot soal"), pickImage)
        }
        save.setOnClickListener { parseBank(); Toast.makeText(this, "Bank tersimpan: ${bank.size} entri", Toast.LENGTH_SHORT).show() }
        match.setOnClickListener { parseBank(); matchQuestion() }
        saveNote.setOnClickListener {
            getSharedPreferences("notes", MODE_PRIVATE).edit()
                .putString("last_note", answerInput.text.toString()).apply()
            Toast.makeText(this, "Catatan disimpan di perangkat", Toast.LENGTH_SHORT).show()
        }
    }

    private fun parseBank() {
        bank.clear()
        bankInput.text.toString().lines().forEach { line ->
            val parts = line.split("|", limit = 2)
            if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank())
                bank.add(parts[0].trim() to parts[1].trim())
        }
    }

    private fun matchQuestion() {
        val q = questionText.text.toString().lowercase()
        if (bank.isEmpty()) {
            resultText.text = "Bank masih kosong. Tambahkan kata kunci dan jawaban terlebih dahulu."
            return
        }
        val hits = bank.mapNotNull { (key, answer) ->
            val words = key.lowercase().split(Regex("\\\\s+")).filter { it.length > 2 }
            val score = words.count { q.contains(it) }
            if (score > 0) Triple(key, answer, score) else null
        }.sortedByDescending { it.third }.take(5)
        resultText.text = if (hits.isEmpty()) "Belum ada kecocokan. Periksa kata kunci atau isi bank jawaban."
        else "Kandidat jawaban (periksa kembali):\\n" + hits.joinToString("\\n\\n") {
            "Kata kunci: ${it.first}\\nJawaban: ${it.second}\\nKecocokan kata: ${it.third}"
        }
    }

    @Deprecated("Deprecated in Android API but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val bitmap: Bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                val image = InputImage.fromBitmap(bitmap, 0)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { visionText ->
                        questionText.text = visionText.text.ifBlank { "Tidak ada teks terbaca. Coba screenshot lebih jelas." }
                    }
                    .addOnFailureListener {
                        questionText.text = "OCR gagal membaca gambar. Coba gambar lain."
                    }
            } catch (e: Exception) {
                questionText.text = "Gambar tidak dapat dibuka."
            }
        }
    }
}
