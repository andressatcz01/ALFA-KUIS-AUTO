# ALFA KUIS AUTO — proyek Android awal

## Fitur versi 1
- Bisa digunakan untuk screenshot dari Chrome Android maupun aplikasi AlfaLearning.
- OCR gambar menggunakan Google ML Kit Text Recognition.
- Bank jawaban lokal dengan format `kata kunci|jawaban`.
- Pencocokan kata kunci dan daftar kandidat jawaban.
- Catatan tersimpan secara lokal di perangkat.

## Batasan yang disengaja
Versi ini tidak membaca layar aplikasi lain secara diam-diam, tidak menggunakan Accessibility untuk menekan tombol, tidak memilih jawaban pada kuis aktif, dan tidak mengirim/menyelesaikan kuis. Pengguna memilih screenshot secara sadar melalui pemilih gambar Android, lalu memeriksa kandidat jawaban sendiri.

## Cara membangun APK
1. Ekstrak ZIP.
2. Buka folder `AlfaKuisAuto` menggunakan Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3).
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Format bank jawaban
Satu entri per baris:
```
fokus|Kemampuan memusatkan perhatian pada suatu hal
promo|Program penawaran harga khusus
```
Gunakan kata kunci yang spesifik. Hasil OCR dan pencocokan bukan jaminan kebenaran; selalu periksa sumber materi dan pilihan jawaban.
